from django.contrib import admin
from .models import StudentDetails
admin.site.register(StudentDetails)
from .models import Receipt
admin.site.register(Receipt)

