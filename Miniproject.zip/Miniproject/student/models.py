# student/models.py
from django.db import models
from django.contrib.auth.models import User

class StudentDetails(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    rnumber = models.CharField(max_length=100)
    full_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    course = models.CharField(max_length=100)
    semester_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0) 

    def __str__(self):
        return self.full_name

class Receipt(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    student = models.ForeignKey(StudentDetails, on_delete=models.CASCADE, null=True)
    course = models.CharField(max_length=50, default='mca')  # Example
    semester = models.CharField(max_length=50)  # Ensure this line exists
    receipt = models.FileField(upload_to='receipts/')
    comments = models.TextField(blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    paid_date = models.DateField()

    def __str__(self):
        return f"{self.course} - {self.semester}"