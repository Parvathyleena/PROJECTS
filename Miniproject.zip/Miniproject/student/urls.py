from django.urls import path
from . import views 
from .views import add_receipt
from .views import view_receipts, edit_receipt, delete_receipt
from .views import home


urlpatterns = [
    
    path('student/', views.student_page, name='student'), 
    path('register/', views.register, name='register'),
    path('', views.student, name='student'),
    path('faculty/', views.faculty, name='faculty'),
    path('logout/', views.logout_view, name='logout'),
    path('add-receipt/', add_receipt, name='add_receipt'),
    path('receipts/', views.view_receipts, name='view_receipts'),
    path('receipts/edit/<int:receipt_id>/', edit_receipt, name='edit_receipt'),
    path('delete_receipt/<int:receipt_id>/', delete_receipt, name='delete_receipt'),
    path('forgot-password/', views.forgot_password_view, name='forgot-password'),
    path('', home, name='home'),
    path('home/', views.home, name='home'),
     # New endpoin
      # Adjust path as needed
]

    
