from django.shortcuts import render
from django.contrib.auth import logout
from django.shortcuts import render, redirect
from .models import StudentDetails,Receipt
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from .forms import Receipt
from .forms import ReceiptForm
from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import send_mail

def home(request):
    return render(request, 'home.html')

def student_page(request):
    return render(request, 'student/student.html')

def register(request):
    if request.method == 'POST':
        rnumber = request.POST.get("rnumber")
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        phone_number = request.POST.get("phone_number")
        course = request.POST.get("course")
        semester_fee = request.POST['semester_fee']
        password = request.POST.get("password")


        user = User.objects.create_user(rnumber, email, password)
        student_details = StudentDetails(full_name=full_name,email=email,phone_number=phone_number,course=course,semester_fee=semester_fee,rnumber=rnumber)
        student_details.save()
        return redirect('login')
    else:
        return render(request, 'account/register.html')

def login(request):
    if request.method == 'POST':
        rnumber = request.POST.get("username")
        password = request.POST.get("password")

        # Debugging output
        print("Request method:", request.method)
        print("Username:", rnumber)

        user = authenticate(request, username=rnumber, password=password)
        print("User authenticated:", user is not None)

        if user is not None:
            auth_login(request, user)

            if request.user.is_staff:
                return redirect('faculty')
            else:
                return redirect('student')
        else:
            # Handle invalid login
            messages.error(request, 'Invalid username or password.')
            # Render the login page again to show the error
            return render(request, 'account/login.html')

    # If not a POST request, render the login page
    return render(request, 'account/login.html')
    
def student(request):
    username = request.user.username
    print(f"Logged in username: {username}")  # Debugging output
    userDetails = StudentDetails.objects.filter(rnumber=username).first()
    
    if userDetails is None:
        return redirect('home')

    context = {
        "student": userDetails
    }
    return render(request, "student/student.html", context)

def faculty(request):
    # username = request.user.username
    # userDetails = StudentDetails.objects.get(rnumber=username)
    context={
        "student":"userDetails"
    }
    return render(request,"faculty/faculty.html",context)

def logout_view(request):
    logout(request)
    return redirect('login')

def add_receipt(request):
    if request.method == 'POST':
        # Extracting form data
        course = request.POST.get('course')
        semester = request.POST.get('semester')
        semester_fee = request.POST.get('semester_fee')
        receipt_file = request.FILES.get('receipt')
        comments = request.POST.get('comments')
        amount = request.POST.get('amount')
        paid_date = request.POST.get('paid-date')

        # Assuming you want to associate the receipt with a student by their register number
        student_rnumber = request.POST.get('student_rnumber')  # Extract this from the form

        try:
            # Fetch the student instance based on the register number
            student = StudentDetails.objects.get(rnumber=student_rnumber)
        except StudentDetails.DoesNotExist:
            # Handle the case where the student does not exist
            return render(request, {'error': 'Student not found.'})

        # Create a new Receipt instance
        receipt = Receipt(
            user=request.user,
            student=student,  # Associate the student instance
            course=course,
            semester=semester,
            receipt=receipt_file,
            comments=comments,
            amount=amount,
            paid_date=paid_date
        )

        # Save the Receipt instance
        receipt.save()

        # Redirect or show a success message
        return redirect('view_receipts')  # Redirect to an appropriate page

    return render(request, 'account/login.html')  # Render the form if not a POST request

def view_receipts(request):
    if request.method == 'POST':
        form = ReceiptForm(request.POST, request.FILES)
        if form.is_valid():
            receipt = form.save(commit=False)
            receipt.user = request.user  # Associate the logged-in user
            receipt.save()
            return redirect('view_receipts')  # Redirect after upload
    else:
        form = ReceiptForm()

    receipts = Receipt.objects.filter(user=request.user)  # Fetch user's receipts
    return render(request, 'student/view_receipts.html', {'form': form, 'receipts': receipts})

def edit_receipt(request, receipt_id):
    receipt = get_object_or_404(Receipt, id=receipt_id, user=request.user)
    if request.method == 'POST':
        form = ReceiptForm(request.POST, request.FILES, instance=receipt)
        if form.is_valid():
            form.save()
            return redirect('view_receipts')  # Redirect to view after saving
    else:
        form = ReceiptForm(instance=receipt)

    return render(request, 'student/edit_receipt.html', {'form': form, 'receipt': receipt})

def delete_receipt(request, receipt_id):
    receipt = get_object_or_404(Receipt, id=receipt_id)
    if request.method == 'POST':
        receipt.delete()
        return redirect('view_receipts')  # Change to your actual receipts list view name
    return render(request, 'student/delete_receipt.html', {'receipt': receipt})

def forgot_password_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        # Logic to handle the email
        messages.success(request, 'Check your email for password reset.')
        return redirect('forgot-password')

    return render(request, 'account/forgotpassword.html')  # This should be the correct path