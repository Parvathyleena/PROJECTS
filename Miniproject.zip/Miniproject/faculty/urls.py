from django.urls import path
from .views import get_students
from django.urls import path
from .views import faculty

urlpatterns = [
    path('get-students/', get_students, name='get_students'),
    path('faculty/', faculty, name='faculty'),
]
