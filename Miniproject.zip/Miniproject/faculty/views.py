from student.models import StudentDetails, Receipt
from django.shortcuts import render 
from .models import Faculty
from django.db.models import Sum
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404

def get_students(request):
    course = request.GET.get('course')
    semester = request.GET.get('semester')

    # Mapping semesters for internal use
    semester_map = {
        'Semester1': 'semester-1',
        'Semester2': 'semester-2',
        'Semester3': 'semester-3',
        'Semester4': 'semester-4',
        'Semester5': 'semester-5',
        'Semester6': 'semester-6',
        'Semester7': 'semester-7',
        'Semester8': 'semester-8',
    }
    
    semester_db = semester_map.get(semester)

    # Debug output
    print(f"Course: {course}, Semester: {semester_db}")

    # Filter students by course
    students = StudentDetails.objects.filter(course=course).order_by('rnumber')

    student_data = []
    for student in students:
        # Get all receipts for the current student and semester
        receipts = Receipt.objects.filter(student=student, semester=semester_db)

        # Calculate the total amount paid
        total_paid = sum(receipt.amount for receipt in receipts)

        # Compare total paid with the semester fee
        status = 'Paid' if total_paid >= student.semester_fee else 'Pending'

        # Debug output for total payments
        print(f"Student {student.rnumber} - Total Paid: {total_paid}, Semester Fee: {student.semester_fee}, Status: {status}")

        # Append the student's data and receipt info
        student_data.append({
            'regNumber': student.rnumber,
            'name': student.full_name,
            'semester': semester,
            'semesterfee': student.semester_fee,
            'receipts': [{'url': receipt.receipt.url, 'comments': receipt.comments,'amount': receipt.amount} for receipt in receipts],
            'amountPaid': total_paid,  # Show the total amount paid
            'status': status  # Dynamic status based on total fee comparison
        })

    return JsonResponse({'students': student_data})

@login_required
def faculty(request):
    faculty_instance = get_object_or_404(Faculty, user=request.user)
    
    print(f"Faculty Name: {faculty_instance.full_name}")  # Debug line
    print(f"Faculty ID: {faculty_instance.idnumber}")    # Debug line
    
    context = {
        'faculty_name': faculty_instance.full_name,
        'faculty_id': faculty_instance.idnumber,
    }
    
    return render(request, 'faculty/faculty.html', context)
