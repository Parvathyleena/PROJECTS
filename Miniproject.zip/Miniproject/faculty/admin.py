from django.contrib import admin
from .models import Faculty

class FacultyAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'idnumber', 'phone_number', 'email')
    search_fields = ('full_name', 'idnumber', 'email')

admin.site.register(Faculty, FacultyAdmin)
