from django.db import models
from django.contrib.auth.models import User  # Assuming each faculty is linked to a User account

class Faculty(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # Link to the User model
    full_name = models.CharField(max_length=100)
    idnumber = models.CharField(max_length=20, unique=True)  # Faculty ID field
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(unique=True)  # Faculty email
    
    def __str__(self):
        return self.full_name
